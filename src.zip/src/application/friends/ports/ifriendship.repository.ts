export { IFriendshipRepository } from "src/domain/repositories/ifriendship.repository";
