export * from "./vk-friends-get-params.dto";
export * from "./vk-friends-get-response.dto";
export * from "./vk-friend.dto";
