import { VkGroup } from "../entities/vk-group";

export interface IGroupRepository {
  findById(id: number): Promise<VkGroup | null>;
  findManyByIds(ids: number[]): Promise<VkGroup[]>;
  save(group: VkGroup): Promise<void>;
  saveMany(groups: VkGroup[]): Promise<void>;
  deleteById(id: number): Promise<void>;
  countSubscriptionsForUser(userId: number): Promise<number>;
  findSubscriptionGroupIds(
    userId: number,
    limit?: number,
    offset?: number,
  ): Promise<number[]>;
}
