export const DomainCacheModuleDeprecated = {} as const;
