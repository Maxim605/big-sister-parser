export { GetVkFriendsUseCase as GetVkFriendsService } from "src/application/use-cases/vk-friends/get-vk-friends.usecase";
