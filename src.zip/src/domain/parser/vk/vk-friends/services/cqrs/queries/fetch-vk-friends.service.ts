export { FetchVkFriendsUseCase as FetchVkFriendsService } from "src/application/use-cases/vk-friends/fetch-vk-friends.usecase";
