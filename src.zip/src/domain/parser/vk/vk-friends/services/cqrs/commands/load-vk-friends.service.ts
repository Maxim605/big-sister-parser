export { LoadVkFriendsUseCase as LoadVkFriendsService } from "src/application/use-cases/vk-friends/load-vk-friends.usecase";
