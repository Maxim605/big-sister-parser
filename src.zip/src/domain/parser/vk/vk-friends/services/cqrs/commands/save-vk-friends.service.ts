export { LoadVkFriendsUseCase as SaveVkFriendsService } from "src/application/use-cases/vk-friends/load-vk-friends.usecase";
