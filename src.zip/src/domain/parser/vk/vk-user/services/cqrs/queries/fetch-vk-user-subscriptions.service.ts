export { FetchVkUserSubscriptionsUseCase as FetchVkUserSubscriptionsService } from "src/application/use-cases/vk-user/fetch-vk-user-subscriptions.usecase";
