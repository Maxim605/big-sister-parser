export { LoadVkUserSubscriptionsUseCase as LoadVkUserSubscriptionsService } from "src/application/use-cases/vk-user/load-vk-user-subscriptions.usecase";
