export { GetVkSubscriptionsUseCase as GetVkSubscriptionsService } from "src/application/use-cases/vk-user/get-vk-subscriptions.usecase";
