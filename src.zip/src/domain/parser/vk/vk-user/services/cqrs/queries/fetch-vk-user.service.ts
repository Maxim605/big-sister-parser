export { FetchVkUserUseCase as FetchVkUserService } from "src/application/use-cases/vk-user/fetch-vk-user.usecase";
