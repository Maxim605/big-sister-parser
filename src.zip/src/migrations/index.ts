import { InitMigration1751961990 } from "./1751961990-InitMigration";
import { AddWallCollections1755735724 } from "./1755735724-AddWallCollections";

export const migrations = [
  InitMigration1751961990,
  AddWallCollections1755735724,
];
